#!/usr/bin/env python3
"""
DOMjudge 문제 ZIP 패키징 (2단계)

사용법:
  전체 패키징:      python problems2zip.py
  특정 문제만:      python problems2zip.py hello aplusb

이전 단계:  python excel2docx.py
입력:       results/docx/{problem_id}.docx  ← 편집된 Word 문서
            results/docx/{problem_id}.json  ← 메타데이터 (excel2docx 생성)
결과:       results/{label}-{problem_id}.zip
"""

import sys
import subprocess
import os
import glob
import json
import zipfile
import tempfile

# Windows 터미널 한글 깨짐 방지
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def _ensure(package: str, import_name: str | None = None) -> None:
    name = import_name or package
    try:
        __import__(name)
    except ImportError:
        print(f"'{package}' 설치 중...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print(f"'{package}' 설치 완료\n")


# ── problem.yaml 생성 ─────────────────────────────────────────────────────────

def make_problem_yaml(meta: dict) -> str:
    def _q(s: str) -> str:
        return ('"' + s
                .replace('\\', '\\\\')
                .replace('"', '\\"')
                .replace('\n', '\\n')
                .replace('\r', '\\r') + '"')
    lines = [
        f"name: {_q(meta['name'])}",
        f"timelimit: {meta['timelimit']}",
        f"memorylimit: {meta['memorylimit']}",
    ]
    if meta.get("source"):
        lines.append(f"source: {_q(meta['source'])}")
    return "\n".join(lines) + "\n"


# ── Word → PDF 변환 ───────────────────────────────────────────────────────────

def docx_to_pdf_win32(docx_path: str, pdf_path: str) -> bool:
    word = None
    doc  = None
    try:
        import win32com.client
        word         = win32com.client.Dispatch("Word.Application")
        word.Visible = False
        doc          = word.Documents.Open(os.path.abspath(docx_path))
        doc.SaveAs(os.path.abspath(pdf_path), FileFormat=17)  # 17 = wdFormatPDF
        return True
    except Exception as e:
        print(f"    [!] win32com PDF 변환 실패: {e}")
        return False
    finally:
        try:
            if doc is not None:
                doc.Close(0)
        except Exception:
            pass
        try:
            if word is not None:
                word.Quit()
        except Exception:
            pass


def docx_to_pdf_libreoffice(docx_path: str, out_dir: str) -> bool:
    candidates = [
        "soffice",
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
    ]
    for soffice in candidates:
        try:
            proc = subprocess.Popen(
                [soffice, "--headless", "--convert-to", "pdf",
                 "--outdir", out_dir, os.path.abspath(docx_path)],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            )
            try:
                proc.communicate(timeout=60)
                if proc.returncode == 0:
                    return True
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.communicate()
                print("    [!] LibreOffice 변환 시간 초과 — 프로세스 종료")
        except FileNotFoundError:
            continue
    return False


def convert_to_pdf(docx_path: str, pdf_path: str) -> bool:
    """win32com 우선, 실패 시 LibreOffice 시도."""
    out_dir = os.path.dirname(pdf_path)

    try:
        import win32com.client  # noqa
    except ImportError:
        print("    'pywin32' 설치 중...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "pywin32"])
            print("    설치 완료. 동작하지 않으면 관리자 권한으로 "
                  "'python Scripts\\pywin32_postinstall.py -install' 실행 후 재시도하세요.")
        except Exception:
            pass

    if docx_to_pdf_win32(docx_path, pdf_path):
        return True

    print("    [!] Word PDF 변환 실패 — LibreOffice 시도 중...")
    base   = os.path.splitext(os.path.basename(docx_path))[0]
    lo_pdf = os.path.join(out_dir, base + ".pdf")

    if docx_to_pdf_libreoffice(docx_path, out_dir):
        if os.path.isfile(lo_pdf) and lo_pdf != pdf_path:
            os.rename(lo_pdf, pdf_path)
        return os.path.isfile(pdf_path)

    return False


# ── ZIP 패키징 ────────────────────────────────────────────────────────────────

def build_zip(problem_id: str, sidecar: dict, pdf_path: str, out_dir: str) -> str:
    """DOMjudge ICPC ZIP 구조로 패키징. 생성된 ZIP 경로 반환."""
    meta     = sidecar["meta"]
    cases    = sidecar["cases"]
    label    = meta.get("label", problem_id)
    zip_path = os.path.join(out_dir, f"{label}-{problem_id}.zip")

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("problem.yaml", make_problem_yaml(meta))
        zf.write(pdf_path, "problem_statement/problem.pdf")

        sample_idx = 1
        secret_idx = 1
        for case in cases:
            if case["type"] == "sample":
                prefix = f"data/sample/{sample_idx}"
                sample_idx += 1
            else:
                prefix = f"data/secret/{secret_idx}"
                secret_idx += 1
            zf.writestr(f"{prefix}.in",  case["input"])
            zf.writestr(f"{prefix}.ans", case["output"])

    return zip_path


# ── 2단계 실행 ────────────────────────────────────────────────────────────────

def run_step2(docx_dir: str, problem_ids: list[str] | None = None) -> None:
    out_dir = os.path.dirname(docx_dir)  # results/

    if problem_ids:
        docx_files = [os.path.join(docx_dir, f"{pid}.docx") for pid in problem_ids]
    else:
        docx_files = sorted(glob.glob(os.path.join(docx_dir, "*.docx")))

    if not docx_files:
        print("오류: results/docx/ 에 docx 파일이 없습니다.")
        print("  먼저 실행:  python excel2docx.py")
        sys.exit(1)

    # 사이드카 존재 여부 사전 확인
    for docx_path in docx_files:
        problem_id = os.path.splitext(os.path.basename(docx_path))[0]
        json_path  = os.path.join(docx_dir, f"{problem_id}.json")
        if not os.path.isfile(docx_path):
            print(f"오류: docx 파일 없음 → {docx_path}")
            sys.exit(1)
        if not os.path.isfile(json_path):
            print(f"오류: 메타데이터 파일 없음 → {json_path}")
            print("  excel2docx.py를 먼저 실행해 JSON 사이드카를 생성하세요.")
            sys.exit(1)

    print("─" * 50)
    print("PDF 변환 및 ZIP 패키징")
    print("─" * 50)

    generated: list[str] = []
    with tempfile.TemporaryDirectory() as tmpdir:
        for docx_path in docx_files:
            problem_id = os.path.splitext(os.path.basename(docx_path))[0]
            json_path  = os.path.join(docx_dir, f"{problem_id}.json")

            with open(json_path, encoding="utf-8") as f:
                sidecar = json.load(f)

            print(f"\n  [{problem_id}]  label={sidecar['meta'].get('label', '?')}")

            pdf_path = os.path.join(tmpdir, f"{problem_id}.pdf")
            if not convert_to_pdf(docx_path, pdf_path):
                print(f"    오류: PDF 변환 실패 (Word와 LibreOffice 모두 실패)")
                print(f"    힌트: Microsoft Word가 설치되어 있는지 확인하세요.")
                sys.exit(1)
            print(f"    PDF 변환 완료")

            try:
                zip_path = build_zip(problem_id, sidecar, pdf_path, out_dir)
            except Exception as e:
                print(f"    오류: ZIP 생성 실패 — {e}")
                sys.exit(1)
            print(f"    ZIP 생성: {os.path.basename(zip_path)}")
            generated.append(zip_path)

    print("\n" + "─" * 50)
    print(f"완료: {len(generated)}개 ZIP 파일 → results/")
    for p in generated:
        print(f"  {os.path.basename(p)}")
    print()
    print("[DOMjudge Import 방법]")
    print("  Jury → Problems → Import problems → 생성된 ZIP 파일 업로드")


# ── 진입점 ────────────────────────────────────────────────────────────────────

def main() -> None:
    args       = sys.argv[1:]
    script_dir = os.path.dirname(os.path.abspath(__file__))
    docx_dir   = os.path.join(script_dir, "results", "docx")

    problem_ids = args if args else None
    run_step2(docx_dir, problem_ids)


if __name__ == "__main__":
    main()
