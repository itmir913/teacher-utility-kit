1. 템플릿 생성
   python 1-excel2docx.py --template
   아래 두 파일이 생성됩니다.
   → problems_template.xlsx (문제 입력 양식)
      problem_template.docx (Word 출력 양식)

   ※ 처음 사용하거나 워크플로우를 테스트하고 싶다면:
      python create_example_problems.py
      → 예시 문제 9개가 채워진 problems_template.xlsx를 생성합니다.
         실제 데이터를 입력하기 전 전체 흐름을 미리 확인하는 데 활용하세요.

2. 엑셀 파일 작성
   problems_template.xlsx를 열어 시트 1개당 문제 1개를 입력합니다.
   시트 이름이 problem_id가 되므로 영문으로 작성합니다. (예: aplusb, sort, dp1)

   각 시트는 세 구역으로 나뉩니다.
     - 메타데이터 (A~B열) : name, label, timelimit 등
     - 문제 설명  (D~E열) : title, description, input_desc, output_desc 등
     - 테스트케이스 (G~I열) : sample / secret 구분 후 입력·출력 작성
       (셀 내 줄바꿈은 Alt+Enter)

3. Word 문서 생성
   엑셀 파일을 저장하고 닫은 뒤 실행합니다.
   python 1-excel2docx.py
   → results/docx/{problem_id}.docx 파일이 문제별로 생성됩니다.
   오류가 있으면 시트 이름과 원인이 표시되므로, 엑셀을 수정 후 다시 실행합니다.

4. Word 문서 편집 (선택)
   results/docx/ 의 docx 파일을 열어 수식, 그림, 서식 등을 자유롭게 수정합니다.
   테스트케이스 데이터는 함께 생성된 .json 파일에 별도 보관되므로,
   docx를 수정해도 테스트케이스에는 영향이 없습니다.

5. ZIP 패키징
   python 2-problems2zip.py
   → docx를 PDF로 변환한 뒤 DOMjudge ICPC ZIP 형식으로 패키징합니다.
      results/{label}-{problem_id}.zip 파일이 문제별로 생성됩니다.
   (PDF 변환에 Microsoft Word 또는 LibreOffice가 필요합니다.)

6. DOMjudge Import
   DOMjudge 관리자 페이지 → Jury → Problems → Import problems
   생성된 ZIP 파일을 문제별로 업로드합니다.