#!/usr/bin/env python3
"""
DOMjudge 문제 Word 문서 생성기 (1단계)

사용법:
  템플릿 생성:  python 1-excel2docx.py --template
  docx 생성:    python 1-excel2docx.py [파일명.xlsx]
                (인자 없으면 problems_template.xlsx 사용)

결과:  results/docx/{problem_id}.docx  ← 자유롭게 편집 가능
       results/docx/{problem_id}.json  ← 2단계용 메타데이터 (수정 금지)
다음:  python 2-problems2zip.py
"""

import sys
import subprocess
import warnings
import os
import json

# Windows 터미널 한글 깨짐 방지
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

warnings.filterwarnings("ignore", message="Data Validation extension is not supported")


def _ensure(package: str, import_name: str | None = None) -> None:
    name = import_name or package
    try:
        __import__(name)
    except ImportError:
        print(f"'{package}' 설치 중...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print(f"'{package}' 설치 완료\n")


_ensure("openpyxl")
_ensure("python-docx", "docx")

import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

DEFAULT_XLSX  = "problems_template.xlsx"
DEFAULT_DOCX  = "problem_template.docx"

META_REQUIRED = {"name", "label", "timelimit"}
META_OPTIONAL = {"memorylimit", "source"}
DESC_REQUIRED = {"title", "description", "input_desc", "output_desc"}
DESC_OPTIONAL = {"notes"}


# ── 엑셀 파싱 ─────────────────────────────────────────────────────────────────

def _cell_str(cell) -> str:
    """셀 값을 문자열로. None이면 빈 문자열."""
    v = cell.value
    if v is None:
        return ""
    return str(v).strip()


def parse_sheet(ws) -> dict:
    """
    시트 1개를 파싱해 problem 딕셔너리 반환.
    {
      "meta":   {name, label, timelimit, memorylimit?, source?},
      "desc":   {title, description, input_desc, output_desc, notes?},
      "cases":  [{"type": "sample"|"secret", "input": str, "output": str}, ...]
    }
    오류 시 ValueError 발생.
    """
    rows = []
    for row in ws.iter_rows(min_row=3, max_row=ws.max_row or 3, max_col=9):
        rows.append(row)

    meta  = {}
    desc  = {}
    cases = []

    for row in rows:
        a = _cell_str(row[0])
        b = row[1].value
        if a:
            b_str = "" if b is None else str(b).strip()
            if a in meta:
                print(f"  [!] 메타데이터 키 중복: '{a}' — '{meta[a]}' → '{b_str}'로 덮어씀")
            meta[a] = b_str

        d = _cell_str(row[3])
        e = row[4].value
        if d:
            e_str = "" if e is None else str(e).strip()
            if d in desc:
                print(f"  [!] 문제 설명 키 중복: '{d}' — 이전 값을 덮어씀")
            desc[d] = e_str

        g_raw = _cell_str(row[6])
        g = g_raw.lower()
        if g in ("sample", "secret"):
            h = row[7].value
            i = row[8].value
            inp = "" if h is None else str(h)
            out = "" if i is None else str(i)
            inp = inp.rstrip("\n") + "\n" if inp else ""
            out = out.rstrip("\n") + "\n" if out else ""
            cases.append({"type": g, "input": inp, "output": out})
        elif g_raw:
            print(f"  [!] {row[6].row}행 [구분] 인식 불가 '{g_raw}' — sample 또는 secret 입력 필요 (무시)")

    missing_meta = META_REQUIRED - set(meta.keys())
    if missing_meta:
        raise ValueError(f"메타데이터 필수 항목 누락: {sorted(missing_meta)}")

    empty_meta = [k for k in META_REQUIRED if meta.get(k, "") == ""]
    if empty_meta:
        raise ValueError(f"메타데이터 필수 항목 값 없음: {sorted(empty_meta)}")

    try:
        meta["timelimit"] = int(float(meta["timelimit"]))
    except (ValueError, KeyError):
        raise ValueError(f"timelimit 값이 정수가 아님: '{meta.get('timelimit', '')}'")

    if "memorylimit" in meta and meta["memorylimit"]:
        try:
            meta["memorylimit"] = int(float(meta["memorylimit"]))
        except ValueError:
            raise ValueError(f"memorylimit 값이 정수가 아님: '{meta['memorylimit']}'")
    else:
        meta["memorylimit"] = 256

    missing_desc = DESC_REQUIRED - set(desc.keys())
    if missing_desc:
        raise ValueError(f"문제 설명 필수 항목 누락: {sorted(missing_desc)}")

    return {"meta": meta, "desc": desc, "cases": cases}


# ── Word 템플릿 헬퍼 ──────────────────────────────────────────────────────────

FONT_DEFAULT = "Pretendard"
FONT_MONO    = "D2Coding"


def _set_run_font(run, name: str, eastasia: str | None = None) -> None:
    run.font.name = name
    ea = eastasia or name
    try:
        rPr = run._r.get_or_add_rPr()
        rFonts = rPr.find(qn("w:rFonts"))
        if rFonts is None:
            rFonts = OxmlElement("w:rFonts")
            rPr.insert(0, rFonts)
        rFonts.set(qn("w:eastAsia"), ea)
        rFonts.set(qn("w:cs"), ea)
    except Exception:
        pass


def _set_doc_default_font(doc: Document, font_name: str) -> None:
    style = doc.styles["Normal"]
    style.font.name = font_name
    try:
        rPr = style.element.get_or_add_rPr()
        rFonts = rPr.find(qn("w:rFonts"))
        if rFonts is None:
            rFonts = OxmlElement("w:rFonts")
            rPr.insert(0, rFonts)
        for attr in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
            rFonts.set(qn(attr), font_name)
    except Exception:
        pass


def _add_para_bottom_border(para, color: str = "DDDDDD", sz: str = "4") -> None:
    pPr = para._p.get_or_add_pPr()
    pBdr = pPr.find(qn("w:pBdr"))
    if pBdr is None:
        pBdr = OxmlElement("w:pBdr")
        pPr.append(pBdr)
    btm = pBdr.find(qn("w:bottom"))
    if btm is None:
        btm = OxmlElement("w:bottom")
        pBdr.append(btm)
    btm.set(qn("w:val"),   "single")
    btm.set(qn("w:sz"),    sz)
    btm.set(qn("w:space"), "1")
    btm.set(qn("w:color"), color)


def _set_cell_bg(cell, fill_color: str) -> None:
    tc   = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd  = tcPr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tcPr.append(shd)
    shd.set(qn("w:val"),   "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"),  fill_color)


def _add_para_left_bar(para, color: str = "1E3A5F", sz: str = "18", space: str = "6") -> None:
    pPr = para._p.get_or_add_pPr()
    pBdr = pPr.find(qn("w:pBdr"))
    if pBdr is None:
        pBdr = OxmlElement("w:pBdr")
        pPr.append(pBdr)
    left = pBdr.find(qn("w:left"))
    if left is None:
        left = OxmlElement("w:left")
        pBdr.append(left)
    left.set(qn("w:val"),   "single")
    left.set(qn("w:sz"),    sz)
    left.set(qn("w:space"), space)
    left.set(qn("w:color"), color)


def _setup_page_footer(section) -> None:
    footer = section.footer
    para   = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
    para.clear()
    para.alignment = WD_ALIGN_PARAGRAPH.CENTER

    r = para.add_run("{{title}}  ·  문제 {{label}}")
    r.font.size      = Pt(9)
    r.font.color.rgb = RGBColor(0xAA, 0xAA, 0xAA)
    _set_run_font(r, FONT_DEFAULT)

    pPr = para._p.get_or_add_pPr()
    pBdr = pPr.find(qn("w:pBdr"))
    if pBdr is None:
        pBdr = OxmlElement("w:pBdr")
        pPr.append(pBdr)
    top = OxmlElement("w:top")
    top.set(qn("w:val"),   "single")
    top.set(qn("w:sz"),    "4")
    top.set(qn("w:space"), "1")
    top.set(qn("w:color"), "CCCCCC")
    pBdr.append(top)


def _add_section_heading(doc: Document, text: str) -> None:
    para = doc.add_paragraph()
    para.paragraph_format.space_before = Pt(18)
    para.paragraph_format.space_after  = Pt(6)
    run = para.add_run(text)
    run.bold           = True
    run.font.size      = Pt(14)
    run.font.color.rgb = RGBColor(0x11, 0x11, 0x11)
    _set_run_font(run, FONT_DEFAULT)
    _add_para_left_bar(para)


def _setup_page_header(section) -> None:
    header = section.header
    para   = header.paragraphs[0] if header.paragraphs else header.add_paragraph()
    para.clear()

    para.paragraph_format.tab_stops.add_tab_stop(Cm(15.0), WD_TAB_ALIGNMENT.RIGHT)

    r_left = para.add_run("[ 여기에 대회명 / 로고를 삽입하세요 ]")
    r_left.italic          = True
    r_left.font.size       = Pt(9)
    r_left.font.color.rgb  = RGBColor(0xBB, 0xBB, 0xBB)
    _set_run_font(r_left, FONT_DEFAULT)

    para.add_run("\t")

    def _pg_run() -> object:
        r = para.add_run()
        r.font.size      = Pt(9)
        r.font.color.rgb = RGBColor(0x88, 0x88, 0x88)
        _set_run_font(r, FONT_DEFAULT)
        return r

    r_begin = _pg_run()
    fld = OxmlElement("w:fldChar")
    fld.set(qn("w:fldCharType"), "begin")
    r_begin._r.append(fld)

    r_instr = _pg_run()
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    r_instr._r.append(instr)

    r_sep = _pg_run()
    fld = OxmlElement("w:fldChar")
    fld.set(qn("w:fldCharType"), "separate")
    r_sep._r.append(fld)

    r_end = _pg_run()
    fld = OxmlElement("w:fldChar")
    fld.set(qn("w:fldCharType"), "end")
    r_end._r.append(fld)

    _add_para_bottom_border(para, color="E0E0E0", sz="4")


# ── docx 플레이스홀더 치환 ────────────────────────────────────────────────────

def _replace_paragraph_placeholder(para, key: str, value: str) -> None:
    full = "".join(r.text for r in para.runs)
    placeholder = f"{{{{{key}}}}}"
    if placeholder not in full:
        return
    if not para.runs:
        return

    replaced  = full.replace(placeholder, value)
    lines     = replaced.split("\n")
    first_run = para.runs[0]

    for r in para.runs[1:]:
        r.text = ""

    first_run.text = lines[0]

    for line in lines[1:]:
        br = OxmlElement("w:br")
        first_run._r.append(br)
        t = OxmlElement("w:t")
        t.set(qn("xml:space"), "preserve")
        t.text = line
        first_run._r.append(t)


def _add_sample_table(doc: Document, cases: list[dict]) -> None:
    samples = [c for c in cases if c["type"] == "sample"]
    if not samples:
        return

    target_para = None
    for para in doc.paragraphs:
        if "{{samples}}" in "".join(r.text for r in para.runs):
            target_para = para
            break
    if target_para is None:
        return

    p_elem     = target_para._element
    parent     = p_elem.getparent()
    insert_idx = list(parent).index(p_elem)
    parent.remove(p_elem)

    for s_idx, case in enumerate(samples, start=1):
        tbl       = doc.add_table(rows=2, cols=2)
        tbl.style = "Table Grid"

        hrow = tbl.rows[0]
        for cell, label in zip(hrow.cells,
                               [f"예제 입력 {s_idx}", f"예제 출력 {s_idx}"]):
            para = cell.paragraphs[0]
            para.clear()
            run                = para.add_run(label)
            run.bold           = True
            run.font.size      = Pt(11)
            run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
            _set_run_font(run, FONT_DEFAULT)
            para.alignment     = WD_ALIGN_PARAGRAPH.CENTER
            _set_cell_bg(cell, "F8F8F8")

        drow = tbl.rows[1]
        for cell, content in zip(drow.cells,
                                 [case["input"].rstrip("\n"),
                                  case["output"].rstrip("\n")]):
            para = cell.paragraphs[0]
            para.clear()
            run           = para.add_run(content)
            run.font.size = Pt(11)
            _set_run_font(run, FONT_MONO)

        tbl_elem = tbl._element
        tbl_elem.getparent().remove(tbl_elem)
        parent.insert(insert_idx, tbl_elem)
        insert_idx += 1

        if s_idx < len(samples):
            sp      = OxmlElement("w:p")
            pPr     = OxmlElement("w:pPr")
            spacing = OxmlElement("w:spacing")
            spacing.set(qn("w:before"), "0")
            spacing.set(qn("w:after"),  "80")
            pPr.append(spacing)
            sp.append(pPr)
            parent.insert(insert_idx, sp)
            insert_idx += 1


def fill_docx_template(template_path: str, problem: dict, out_docx: str) -> None:
    doc  = Document(template_path)
    meta  = problem["meta"]
    desc  = problem["desc"]
    cases = problem["cases"]

    def _remove_section(placeholder: str) -> None:
        paras = list(doc.paragraphs)
        for i, para in enumerate(paras):
            if placeholder in "".join(r.text for r in para.runs):
                para._element.getparent().remove(para._element)
                if i > 0:
                    prev = paras[i - 1]._element
                    prev.getparent().remove(prev)
                break

    if not any(c["type"] == "sample" for c in cases):
        _remove_section("{{samples}}")

    if not desc.get("notes", "").strip():
        _remove_section("{{notes}}")

    replacements = {
        "title":       desc.get("title", ""),
        "description": desc.get("description", ""),
        "input_desc":  desc.get("input_desc", ""),
        "output_desc": desc.get("output_desc", ""),
        "notes":       desc.get("notes", ""),
        "timelimit":   str(meta.get("timelimit", "")),
        "memorylimit": str(meta.get("memorylimit", "")),
        "label":       meta.get("label", ""),
    }

    for para in doc.paragraphs:
        for key, val in replacements.items():
            _replace_paragraph_placeholder(para, key, val)

    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    for key, val in replacements.items():
                        _replace_paragraph_placeholder(para, key, val)

    for section in doc.sections:
        for para in section.header.paragraphs:
            for key, val in replacements.items():
                _replace_paragraph_placeholder(para, key, val)
        for para in section.footer.paragraphs:
            for key, val in replacements.items():
                _replace_paragraph_placeholder(para, key, val)

    _add_sample_table(doc, cases)
    doc.save(out_docx)


# ── 1단계 실행 ────────────────────────────────────────────────────────────────

def run_step1(xlsx_path: str, template_docx: str) -> None:
    script_dir = os.path.dirname(os.path.abspath(xlsx_path))
    docx_dir   = os.path.join(script_dir, "results", "docx")
    os.makedirs(docx_dir, exist_ok=True)
    print(f"읽는 중: {xlsx_path}\n")

    wb           = openpyxl.load_workbook(xlsx_path, data_only=True, read_only=True)
    sheet_names  = wb.sheetnames

    if not sheet_names:
        print("오류: 시트가 없습니다.")
        sys.exit(1)

    if not os.path.isfile(template_docx):
        print(f"오류: Word 템플릿을 찾을 수 없습니다 → {template_docx}")
        print(f"  템플릿 생성:  python {os.path.basename(__file__)} --template")
        sys.exit(1)

    problems: list[tuple[str, dict]] = []

    print("─" * 50)
    print("파싱 및 검증")
    print("─" * 50)
    for sheet_name in sheet_names:
        ws = wb[sheet_name]
        print(f"  [{sheet_name}] 파싱 중...")
        try:
            problem = parse_sheet(ws)
        except ValueError as e:
            print(f"  [{sheet_name}] 오류: {e}")
            sys.exit(1)

        sample_count = sum(1 for c in problem["cases"] if c["type"] == "sample")
        secret_count = sum(1 for c in problem["cases"] if c["type"] == "secret")
        print(f"    name={problem['meta']['name']}, label={problem['meta']['label']}, "
              f"timelimit={problem['meta']['timelimit']}s, mem={problem['meta']['memorylimit']}MB")
        print(f"    sample={sample_count}개, secret={secret_count}개")
        if sample_count == 0:
            print(f"  [{sheet_name}] 오류: sample 케이스가 없습니다.")
            sys.exit(1)
        if secret_count == 0:
            print(f"  [{sheet_name}] 오류: secret 케이스가 없습니다.")
            sys.exit(1)
        problems.append((sheet_name, problem))

    labels = [p["meta"]["label"] for _, p in problems]
    seen_labels: set[str] = set()
    dup_labels:  list[str] = []
    for lbl in labels:
        if lbl.upper() in seen_labels:
            dup_labels.append(lbl)
        seen_labels.add(lbl.upper())
    if dup_labels:
        print(f"\n오류: label 중복 (대소문자 무관): {dup_labels}")
        sys.exit(1)

    print(f"\n[OK] {len(problems)}개 문제 검증 완료\n")

    print("─" * 50)
    print("Word 문서 생성")
    print("─" * 50)

    generated: list[str] = []
    for problem_id, problem in problems:
        print(f"\n  [{problem_id}]")

        out_docx = os.path.join(docx_dir, f"{problem_id}.docx")
        try:
            fill_docx_template(template_docx, problem, out_docx)
        except Exception as e:
            print(f"    오류: Word 문서 생성 실패 — {e}")
            sys.exit(1)
        print(f"    docx 생성: {os.path.relpath(out_docx, script_dir)}")

        sidecar = {
            "problem_id": problem_id,
            "meta":  problem["meta"],
            "cases": problem["cases"],
        }
        out_json = os.path.join(docx_dir, f"{problem_id}.json")
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(sidecar, f, ensure_ascii=False, indent=2)

        generated.append(out_docx)

    print("\n" + "─" * 50)
    print(f"완료: {len(generated)}개 docx 파일 → results/docx/")
    for p in generated:
        print(f"  {os.path.basename(p)}")
    print()
    print("docx 수정 후 다음 단계:")
    print("  python 2-problems2zip.py")


# ── 템플릿 생성 ───────────────────────────────────────────────────────────────

def create_xlsx_template(output_path: str) -> None:
    wb = Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet(title="hello")

    CLR_META  = "2E75B6"
    CLR_DESC  = "70AD47"
    CLR_CASE  = "C55A11"
    CLR_DIV   = "D9D9D9"
    CLR_WHITE = "FFFFFF"

    header_font = Font(bold=True, color=CLR_WHITE, size=11)
    center      = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws.merge_cells("A1:B1")
    c = ws["A1"]
    c.value, c.font, c.fill, c.alignment = (
        "메타데이터", header_font,
        PatternFill(fill_type="solid", fgColor=CLR_META), center,
    )
    ws["C1"].fill = PatternFill(fill_type="solid", fgColor=CLR_DIV)

    ws.merge_cells("D1:E1")
    c = ws["D1"]
    c.value, c.font, c.fill, c.alignment = (
        "문제 설명", header_font,
        PatternFill(fill_type="solid", fgColor=CLR_DESC), center,
    )
    ws["F1"].fill = PatternFill(fill_type="solid", fgColor=CLR_DIV)

    ws.merge_cells("G1:I1")
    c = ws["G1"]
    c.value, c.font, c.fill, c.alignment = (
        "테스트케이스", header_font,
        PatternFill(fill_type="solid", fgColor=CLR_CASE), center,
    )

    sub_font = Font(bold=True, size=10, color="333333")
    headers  = [
        ("A2", "키",   "BDD7EE"), ("B2", "값",   "BDD7EE"), ("C2", "",     CLR_DIV),
        ("D2", "항목", "C6EFCE"), ("E2", "내용", "C6EFCE"), ("F2", "",     CLR_DIV),
        ("G2", "구분", "FCE4D6"), ("H2", "입력", "FCE4D6"), ("I2", "출력", "FCE4D6"),
    ]
    for addr, val, clr in headers:
        c = ws[addr]
        c.value, c.font = val, sub_font
        c.fill          = PatternFill(fill_type="solid", fgColor=clr)
        c.alignment     = center

    meta_rows = [
        ("name",        "두 수의 합"),
        ("label",       "A"),
        ("timelimit",   "2"),
        ("memorylimit", "256"),
        ("source",      "CONTEST"),
    ]
    desc_rows = [
        ("title",       "두 수의 합"),
        ("description", "두 정수 A, B가 주어진다.\nA와 B의 합을 출력하라."),
        ("input_desc",  "첫째 줄에 두 정수 A, B가 주어진다. (1 ≤ A, B ≤ 1000)"),
        ("output_desc", "A+B를 출력한다."),
        ("notes",       "(선택) 추가 설명"),
    ]
    case_rows = [
        ("sample", "1 2",   "3"),
        ("sample", "10 20", "30"),
        ("secret", "999 1", "1000"),
    ]

    ex_font = Font(color="777777", italic=True, size=10)
    ex_fill = PatternFill(fill_type="solid", fgColor="F2F2F2")
    wrap    = Alignment(vertical="top", wrap_text=True)

    max_rows = max(len(meta_rows), len(desc_rows), len(case_rows))
    for i in range(max_rows):
        row = i + 3
        ws[f"C{row}"].fill = PatternFill(fill_type="solid", fgColor=CLR_DIV)
        ws[f"F{row}"].fill = PatternFill(fill_type="solid", fgColor=CLR_DIV)

        if i < len(meta_rows):
            k, v = meta_rows[i]
            for col, val in zip(["A", "B"], [k, v]):
                c = ws[f"{col}{row}"]
                c.value, c.font, c.fill, c.alignment = val, ex_font, ex_fill, wrap

        if i < len(desc_rows):
            k, v = desc_rows[i]
            for col, val in zip(["D", "E"], [k, v]):
                c = ws[f"{col}{row}"]
                c.value, c.font, c.fill, c.alignment = val, ex_font, ex_fill, wrap

        if i < len(case_rows):
            g, h, ii = case_rows[i]
            for col, val in zip(["G", "H", "I"], [g, h, ii]):
                c = ws[f"{col}{row}"]
                c.value, c.font, c.fill, c.alignment = val, ex_font, ex_fill, wrap

    col_widths = {"A": 14, "B": 28, "C": 2, "D": 14, "E": 40, "F": 2, "G": 10, "H": 20, "I": 20}
    for col, width in col_widths.items():
        ws.column_dimensions[col].width = width
    ws.row_dimensions[1].height = 22
    ws.row_dimensions[2].height = 20
    ws.freeze_panes = "A3"

    try:
        wb.save(output_path)
    except PermissionError:
        print(f"오류: '{os.path.basename(output_path)}' 파일이 열려 있습니다. Excel을 닫고 다시 실행하세요.")
        sys.exit(1)

    print(f"엑셀 템플릿 생성됨: {output_path}")


def create_docx_template(output_path: str) -> None:
    doc = Document()

    for section in doc.sections:
        section.top_margin      = Cm(2.5)
        section.bottom_margin   = Cm(2.0)
        section.left_margin     = Cm(2.0)
        section.right_margin    = Cm(2.0)
        section.header_distance = Cm(1.0)
        _setup_page_header(section)
        _setup_page_footer(section)

    _set_doc_default_font(doc, FONT_DEFAULT)

    def _body_para(placeholder: str) -> None:
        para = doc.add_paragraph()
        para.paragraph_format.space_before = Pt(4)
        para.paragraph_format.space_after  = Pt(4)
        run = para.add_run(placeholder)
        run.font.size = Pt(12)
        _set_run_font(run, FONT_DEFAULT)
        blank = doc.add_paragraph()
        blank.paragraph_format.space_before = Pt(0)
        blank.paragraph_format.space_after  = Pt(0)

    lbl_para = doc.add_paragraph()
    lbl_para.paragraph_format.space_before = Pt(0)
    lbl_para.paragraph_format.space_after  = Pt(2)
    r = lbl_para.add_run("문제 {{label}}")
    r.font.size      = Pt(12)
    r.font.color.rgb = RGBColor(0x88, 0x88, 0x88)
    _set_run_font(r, FONT_DEFAULT)

    title_para = doc.add_paragraph()
    title_para.paragraph_format.space_before = Pt(0)
    title_para.paragraph_format.space_after  = Pt(8)
    r = title_para.add_run("{{title}}")
    r.bold           = True
    r.font.size      = Pt(24)
    r.font.color.rgb = RGBColor(0x11, 0x11, 0x11)
    _set_run_font(r, FONT_DEFAULT)

    limit_para = doc.add_paragraph()
    limit_para.paragraph_format.space_before = Pt(10)
    limit_para.paragraph_format.space_after  = Pt(10)
    r = limit_para.add_run("시간 제한:  {{timelimit}}초     메모리 제한:  {{memorylimit}} MB")
    r.font.size      = Pt(11)
    r.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
    _set_run_font(r, FONT_DEFAULT)
    _add_para_bottom_border(limit_para, color="CCCCCC", sz="4")

    blank = doc.add_paragraph()
    blank.paragraph_format.space_before = Pt(0)
    blank.paragraph_format.space_after  = Pt(0)
    _add_section_heading(doc, "문제")
    _body_para("{{description}}")

    _add_section_heading(doc, "입력")
    _body_para("{{input_desc}}")

    _add_section_heading(doc, "출력")
    _body_para("{{output_desc}}")

    _add_section_heading(doc, "입출력 예시")
    ph_para = doc.add_paragraph()
    ph_para.paragraph_format.space_before = Pt(2)
    ph_para.paragraph_format.space_after  = Pt(2)
    r = ph_para.add_run("{{samples}}")
    r.font.size      = Pt(9)
    r.font.color.rgb = RGBColor(0xCC, 0x44, 0x44)
    _set_run_font(r, FONT_DEFAULT)
    blank = doc.add_paragraph()
    blank.paragraph_format.space_before = Pt(0)
    blank.paragraph_format.space_after  = Pt(0)

    _add_section_heading(doc, "노트")
    _body_para("{{notes}}")

    try:
        doc.save(output_path)
    except PermissionError:
        print(f"오류: '{os.path.basename(output_path)}' 파일이 열려 있습니다. Word를 닫고 다시 실행하세요.")
        sys.exit(1)

    print(f"Word 템플릿 생성됨: {output_path}")


def create_templates(script_dir: str) -> None:
    targets = [
        (os.path.join(script_dir, DEFAULT_XLSX), create_xlsx_template),
        (os.path.join(script_dir, DEFAULT_DOCX), create_docx_template),
    ]
    for path, creator in targets:
        if os.path.isfile(path):
            answer = input(f"'{os.path.basename(path)}' 이 이미 존재합니다. 덮어쓸까요? [y/N] ").strip().lower()
            if answer != "y":
                print(f"  '{os.path.basename(path)}' 건너뜀.")
                continue
        creator(path)

    print()
    print("─" * 60)
    print("엑셀 시트 구조:")
    print("  시트 이름  = problem_id (예: hello, A, problem1)")
    print()
    print("  [메타데이터] A열=키, B열=값")
    print("    ★ name        : 문제 이름")
    print("    ★ label       : 문제 레이블 (A, B, C ...)")
    print("    ★ timelimit   : 시간 제한 (초)")
    print("    ○ memorylimit : 메모리 제한 MB (기본 256)")
    print("    ○ source      : 대회명")
    print()
    print("  [문제 설명] D열=항목, E열=내용")
    print("    ★ title       : 문제 제목")
    print("    ★ description : 문제 본문")
    print("    ★ input_desc  : 입력 설명")
    print("    ★ output_desc : 출력 설명")
    print("    ○ notes       : 노트 (선택)")
    print()
    print("  [테스트케이스] G열=구분, H열=입력, I열=출력")
    print("    sample / secret 중 하나 입력")
    print()
    print("  셀 내 줄바꿈: Alt+Enter")
    print()
    print("★ = 필수   ○ = 선택")
    print("─" * 60)
    print()
    print("Word 템플릿 플레이스홀더:")
    print("  {{label}}       {{title}}      {{timelimit}}  {{memorylimit}}")
    print("  {{description}} {{input_desc}} {{output_desc}}")
    print("  {{notes}}       {{samples}}  (← 입출력 예시 표 자동 생성)")


# ── 진입점 ────────────────────────────────────────────────────────────────────

def main() -> None:
    args       = sys.argv[1:]
    script_dir = os.path.dirname(os.path.abspath(__file__))

    if "--template" in args:
        create_templates(script_dir)
        return

    xlsx_name = args[0] if args else DEFAULT_XLSX
    xlsx_path = xlsx_name if os.path.isabs(xlsx_name) else os.path.join(script_dir, xlsx_name)

    if not os.path.isfile(xlsx_path):
        print(f"오류: 파일을 찾을 수 없습니다 → {xlsx_path}")
        print(f"  템플릿 생성:  python {os.path.basename(__file__)} --template")
        sys.exit(1)

    template_docx = os.path.join(os.path.dirname(os.path.abspath(xlsx_path)), DEFAULT_DOCX)
    run_step1(xlsx_path, template_docx)


if __name__ == "__main__":
    main()
