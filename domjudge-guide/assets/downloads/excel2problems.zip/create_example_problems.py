#!/usr/bin/env python3
"""9개 기초 문제를 problems_template.xlsx에 작성."""

import os
import sys
import subprocess

def _ensure(package, import_name=None):
    name = import_name or package
    try:
        __import__(name)
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])

_ensure("openpyxl")

import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "problems_template.xlsx")

CLR_META  = "2E75B6"
CLR_DESC  = "70AD47"
CLR_CASE  = "C55A11"
CLR_DIV   = "D9D9D9"
CLR_WHITE = "FFFFFF"

PROBLEMS = [
    {
        "sheet": "hello",
        "meta": {
            "name": "Hello World",
            "label": "A",
            "timelimit": "1",
            "memorylimit": "256",
            "source": "CONTEST",
        },
        "desc": {
            "title": "Hello World",
            "description": "Hello World를 출력하라.",
            "input_desc": "입력이 없다.",
            "output_desc": "Hello World를 출력한다.",
        },
        "cases": [
            {"type": "sample", "input": "", "output": "Hello World"},
            {"type": "secret", "input": "", "output": "Hello World"},
        ],
    },
    {
        "sheet": "echo",
        "meta": {
            "name": "그대로 출력",
            "label": "B",
            "timelimit": "1",
            "memorylimit": "256",
            "source": "CONTEST",
        },
        "desc": {
            "title": "그대로 출력",
            "description": "문자열 한 줄이 주어진다. 그 문자열을 그대로 출력하라.",
            "input_desc": "길이가 1 이상 100 이하인 문자열이 한 줄로 주어진다.",
            "output_desc": "입력된 문자열을 그대로 출력한다.",
        },
        "cases": [
            {"type": "sample", "input": "GFPC", "output": "GFPC"},
            {"type": "sample", "input": "Hello", "output": "Hello"},
            {"type": "secret", "input": "abcde", "output": "abcde"},
            {"type": "secret", "input": "12345", "output": "12345"},
        ],
    },
    {
        "sheet": "aplusb",
        "meta": {
            "name": "두 수의 합",
            "label": "C",
            "timelimit": "1",
            "memorylimit": "256",
            "source": "CONTEST",
        },
        "desc": {
            "title": "두 수의 합",
            "description": "두 정수 A, B가 주어진다. A와 B의 합을 출력하라.",
            "input_desc": "첫째 줄에 두 정수 A, B가 주어진다. (1 ≤ A, B ≤ 1000)",
            "output_desc": "A+B를 출력한다.",
        },
        "cases": [
            {"type": "sample", "input": "3 5", "output": "8"},
            {"type": "sample", "input": "10 20", "output": "30"},
            {"type": "secret", "input": "1 1", "output": "2"},
            {"type": "secret", "input": "999 1", "output": "1000"},
            {"type": "secret", "input": "500 500", "output": "1000"},
        ],
    },
    {
        "sheet": "amulb",
        "meta": {
            "name": "두 수의 곱",
            "label": "D",
            "timelimit": "1",
            "memorylimit": "256",
            "source": "CONTEST",
        },
        "desc": {
            "title": "두 수의 곱",
            "description": "두 정수 A, B가 주어진다. A와 B의 곱을 출력하라.",
            "input_desc": "첫째 줄에 두 정수 A, B가 주어진다. (1 ≤ A, B ≤ 100)",
            "output_desc": "A×B를 출력한다.",
        },
        "cases": [
            {"type": "sample", "input": "4 5", "output": "20"},
            {"type": "sample", "input": "3 3", "output": "9"},
            {"type": "secret", "input": "1 1", "output": "1"},
            {"type": "secret", "input": "100 100", "output": "10000"},
            {"type": "secret", "input": "7 8", "output": "56"},
        ],
    },
    {
        "sheet": "fourops",
        "meta": {
            "name": "사칙연산",
            "label": "E",
            "timelimit": "1",
            "memorylimit": "256",
            "source": "CONTEST",
        },
        "desc": {
            "title": "사칙연산",
            "description": "두 정수 A, B가 주어진다.\nA+B, A-B, A×B, A÷B를 각각 한 줄씩 출력하라.\nA는 B의 배수임이 보장된다.",
            "input_desc": "첫째 줄에 두 정수 A, B가 주어진다. (1 ≤ B ≤ A ≤ 100, A는 B의 배수)",
            "output_desc": "첫째 줄에 A+B, 둘째 줄에 A-B, 셋째 줄에 A×B, 넷째 줄에 A÷B를 출력한다.",
        },
        "cases": [
            {"type": "sample", "input": "10 2", "output": "12\n8\n20\n5"},
            {"type": "sample", "input": "6 3", "output": "9\n3\n18\n2"},
            {"type": "secret", "input": "1 1", "output": "2\n0\n1\n1"},
            {"type": "secret", "input": "100 10", "output": "110\n90\n1000\n10"},
        ],
    },
    {
        "sheet": "abs",
        "meta": {
            "name": "절댓값",
            "label": "F",
            "timelimit": "1",
            "memorylimit": "256",
            "source": "CONTEST",
        },
        "desc": {
            "title": "절댓값",
            "description": "정수 N이 주어진다. N의 절댓값을 출력하라.",
            "input_desc": "첫째 줄에 정수 N이 주어진다. (-1000 ≤ N ≤ 1000)",
            "output_desc": "N의 절댓값을 출력한다.",
        },
        "cases": [
            {"type": "sample", "input": "-7", "output": "7"},
            {"type": "sample", "input": "5", "output": "5"},
            {"type": "sample", "input": "0", "output": "0"},
            {"type": "secret", "input": "-1000", "output": "1000"},
            {"type": "secret", "input": "1000", "output": "1000"},
            {"type": "secret", "input": "-1", "output": "1"},
        ],
    },
    {
        "sheet": "oddeven",
        "meta": {
            "name": "홀수 짝수",
            "label": "G",
            "timelimit": "1",
            "memorylimit": "256",
            "source": "CONTEST",
        },
        "desc": {
            "title": "홀수 짝수",
            "description": "정수 N이 주어진다.\nN이 홀수이면 Odd, 짝수이면 Even을 출력하라.",
            "input_desc": "첫째 줄에 정수 N이 주어진다. (1 ≤ N ≤ 1000)",
            "output_desc": "N이 홀수이면 Odd, 짝수이면 Even을 출력한다.",
        },
        "cases": [
            {"type": "sample", "input": "4", "output": "Even"},
            {"type": "sample", "input": "7", "output": "Odd"},
            {"type": "secret", "input": "1", "output": "Odd"},
            {"type": "secret", "input": "1000", "output": "Even"},
            {"type": "secret", "input": "999", "output": "Odd"},
        ],
    },
    {
        "sheet": "compare",
        "meta": {
            "name": "두 수 비교",
            "label": "H",
            "timelimit": "1",
            "memorylimit": "256",
            "source": "CONTEST",
        },
        "desc": {
            "title": "두 수 비교",
            "description": "두 정수 A, B가 주어진다.\nA가 B보다 크면 >, 작으면 <, 같으면 =을 출력하라.",
            "input_desc": "첫째 줄에 두 정수 A, B가 주어진다. (1 ≤ A, B ≤ 1000)",
            "output_desc": "A > B이면 >, A < B이면 <, A = B이면 =을 출력한다.",
        },
        "cases": [
            {"type": "sample", "input": "3 5", "output": "<"},
            {"type": "sample", "input": "7 2", "output": ">"},
            {"type": "sample", "input": "4 4", "output": "="},
            {"type": "secret", "input": "1 1000", "output": "<"},
            {"type": "secret", "input": "1000 1", "output": ">"},
            {"type": "secret", "input": "500 500", "output": "="},
        ],
    },
    {
        "sheet": "sign",
        "meta": {
            "name": "양수 음수 영",
            "label": "I",
            "timelimit": "1",
            "memorylimit": "256",
            "source": "CONTEST",
        },
        "desc": {
            "title": "양수 음수 영",
            "description": "정수 N이 주어진다.\nN이 양수이면 Positive, 음수이면 Negative, 0이면 Zero를 출력하라.",
            "input_desc": "첫째 줄에 정수 N이 주어진다. (-1000 ≤ N ≤ 1000)",
            "output_desc": "N이 양수이면 Positive, 음수이면 Negative, 0이면 Zero를 출력한다.",
        },
        "cases": [
            {"type": "sample", "input": "5", "output": "Positive"},
            {"type": "sample", "input": "-3", "output": "Negative"},
            {"type": "sample", "input": "0", "output": "Zero"},
            {"type": "secret", "input": "1000", "output": "Positive"},
            {"type": "secret", "input": "-1000", "output": "Negative"},
            {"type": "secret", "input": "-1", "output": "Negative"},
        ],
    },
]


def make_sheet(wb: Workbook, prob: dict) -> None:
    ws = wb.create_sheet(title=prob["sheet"])

    header_font = Font(bold=True, color=CLR_WHITE, size=11)
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    sub_font = Font(bold=True, size=10, color="333333")
    wrap = Alignment(vertical="top", wrap_text=True)

    def fill(color):
        return PatternFill(fill_type="solid", fgColor=color)

    # 1행: 섹션 제목
    ws.merge_cells("A1:B1")
    ws["A1"].value, ws["A1"].font, ws["A1"].fill, ws["A1"].alignment = "메타데이터", header_font, fill(CLR_META), center
    ws["C1"].fill = fill(CLR_DIV)
    ws.merge_cells("D1:E1")
    ws["D1"].value, ws["D1"].font, ws["D1"].fill, ws["D1"].alignment = "문제 설명", header_font, fill(CLR_DESC), center
    ws["F1"].fill = fill(CLR_DIV)
    ws.merge_cells("G1:I1")
    ws["G1"].value, ws["G1"].font, ws["G1"].fill, ws["G1"].alignment = "테스트케이스", header_font, fill(CLR_CASE), center

    # 2행: 열 헤더
    headers = [
        ("A2", "키",   "BDD7EE"), ("B2", "값",   "BDD7EE"), ("C2", "",     CLR_DIV),
        ("D2", "항목", "C6EFCE"), ("E2", "내용", "C6EFCE"), ("F2", "",     CLR_DIV),
        ("G2", "구분", "FCE4D6"), ("H2", "입력", "FCE4D6"), ("I2", "출력", "FCE4D6"),
    ]
    for addr, val, clr in headers:
        c = ws[addr]
        c.value, c.font, c.fill, c.alignment = val, sub_font, fill(clr), center

    # 3행~: 데이터
    meta_items = list(prob["meta"].items())
    desc_items = list(prob["desc"].items())
    case_items = prob["cases"]
    max_rows = max(len(meta_items), len(desc_items), len(case_items))

    for i in range(max_rows):
        row = i + 3
        ws[f"C{row}"].fill = fill(CLR_DIV)
        ws[f"F{row}"].fill = fill(CLR_DIV)

        if i < len(meta_items):
            k, v = meta_items[i]
            ws[f"A{row}"].value, ws[f"A{row}"].alignment = k, wrap
            ws[f"B{row}"].value, ws[f"B{row}"].alignment = v, wrap

        if i < len(desc_items):
            k, v = desc_items[i]
            ws[f"D{row}"].value, ws[f"D{row}"].alignment = k, wrap
            ws[f"E{row}"].value, ws[f"E{row}"].alignment = v, wrap

        if i < len(case_items):
            c = case_items[i]
            ws[f"G{row}"].value, ws[f"G{row}"].alignment = c["type"], wrap
            ws[f"H{row}"].value, ws[f"H{row}"].alignment = c["input"], wrap
            ws[f"I{row}"].value, ws[f"I{row}"].alignment = c["output"], wrap

    # 열 너비
    for col, width in [("A",14),("B",28),("C",2),("D",14),("E",40),("F",2),("G",10),("H",20),("I",20)]:
        ws.column_dimensions[col].width = width
    ws.row_dimensions[1].height = 22
    ws.row_dimensions[2].height = 20
    ws.freeze_panes = "A3"


def main():
    wb = Workbook()
    wb.remove(wb.active)
    for prob in PROBLEMS:
        make_sheet(wb, prob)
    wb.save(OUT)
    print(f"완료: {OUT}")
    print(f"총 {len(PROBLEMS)}개 시트 생성")
    for p in PROBLEMS:
        print(f"  [{p['meta']['label']}] {p['meta']['name']}  ({p['sheet']})")


if __name__ == "__main__":
    main()
