1. 템플릿 생성
   python excel2domjudge.py --template
   → 스크립트와 같은 폴더에 domjudge_templates.xlsx 파일이 생성됩니다.

2. 엑셀 파일 작성
   생성된 xlsx를 열면 4개 시트가 있습니다.
     - groups       : 팀 카테고리 (예: 고등부, 대학부)
     - organizations: 학교/소속 목록
     - teams        : 팀 목록
     - accounts     : 로그인 계정 목록

   회색으로 표시된 예시 행을 참고해 실제 데이터를 입력한 뒤, 예시 행은 삭제합니다.
   파란 헤더는 필수, 초록 헤더는 선택, 주황 헤더는 다른 시트의 값을 참조하는 필드입니다.
   (주황 헤더 셀을 클릭하면 드롭다운으로 앞 시트의 값을 선택할 수 있습니다.)

   ※ 시트 간 참조 관계:
     teams.group_ids        → groups.id
     teams.organization_id  → organizations.id
     accounts.team_id       → teams.id

3. JSON 변환
   엑셀 파일을 저장하고 닫은 뒤 실행합니다.
   python excel2domjudge.py
   → result/ 폴더에 JSON 파일 4개가 생성됩니다.
   오류가 있으면 메시지에 행 번호와 원인이 표시되므로, 엑셀을 수정 후 다시 실행합니다.

4. DOMjudge Import
   DOMjudge 관리자 페이지 → Import/Export → Import JSON/YAML
   아래 순서대로 각 파일을 import합니다. (순서를 지켜야 합니다.)
     1) 1-groups.json
     2) 2-organizations.json
     3) 3-teams.json
     4) 4-accounts.json