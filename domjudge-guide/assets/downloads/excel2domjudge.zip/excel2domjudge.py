#!/usr/bin/env python3
"""
DOMjudge 9.0 bulk import JSON 생성기

사용법:
  JSON 변환:    python excel2domjudge.py [엑셀파일.xlsx]
                (인자 없으면 domjudge_templates.xlsx 사용)
  템플릿 생성:  python excel2domjudge.py --template
"""

import sys
import subprocess
import warnings

# Windows 터미널 한글 깨짐 방지
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# openpyxl 데이터 유효성 검사 경고 억제
warnings.filterwarnings("ignore", message="Data Validation extension is not supported")

def _ensure(package: str) -> None:
    try:
        __import__(package)
    except ImportError:
        print(f"'{package}' 설치 중...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print(f"'{package}' 설치 완료\n")

_ensure("openpyxl")

import json
import os
import zipfile
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.comments import Comment
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation


# ── 스키마 정의 ──────────────────────────────────────────────────────────────
# key      : DOMjudge JSON 키 (= 엑셀 헤더)
# required : 필수 여부 (빈 셀이면 해당 행 전체 스킵)
# type     : str / bool / int / list (list는 콤마 구분 → JSON 배열)
# desc     : 헤더 셀 주석(툴팁)으로 표시

SCHEMAS: dict = {
    "groups": {
        "fields": [
            {"key": "id",        "required": True,  "type": "str",  "desc": "카테고리 ID (고유값)"},
            {"key": "icpc_id",   "required": False, "type": "str",  "desc": "ICPC CMS ID (선택)"},
            {"key": "name",      "required": True,  "type": "str",  "desc": "스코어보드에 표시될 팀 카테고리 이름"},
            {"key": "hidden",    "required": False, "type": "bool", "desc": "true이면 스코어보드에서 숨김 (기본: false)"},
            {"key": "sortorder", "required": False, "type": "int",  "desc": "스코어보드 정렬 순서 (기본: 0)"},
        ],
        "examples": [
            {"id": "highschool", "name": "고등부", "hidden": "false", "sortorder": "0"},
            {"id": "univ",       "name": "대학부", "hidden": "false", "sortorder": "1"},
        ],
    },
    "organizations": {
        "fields": [
            {"key": "id",          "required": True,  "type": "str", "desc": "소속 ID (고유값, 예: INST-gochon)"},
            {"key": "icpc_id",     "required": False, "type": "str", "desc": "ICPC CMS ID (선택)"},
            {"key": "name",        "required": True,  "type": "str", "desc": "소속 약칭 — 영문 단어 권장 (jury 인터페이스 표시용)"},
            {"key": "formal_name", "required": True,  "type": "str", "desc": "소속 전체 이름 (스코어보드 표시용)"},
            {"key": "country",     "required": True,  "type": "str", "desc": "ISO 3166-1 alpha-3 국가 코드 (예: KOR)"},
        ],
        "examples": [
            {"id": "INST-aa", "name": "Aa", "formal_name": "AA고등학교", "country": "KOR"},
            {"id": "INST-bb", "name": "Bb", "formal_name": "BB고등학교", "country": "KOR"},
            {"id": "INST-cc", "name": "Cc", "formal_name": "CC고등학교", "country": "KOR"},
        ],
    },
    "teams": {
        "fields": [
            {"key": "id",                   "required": True,  "type": "str",  "desc": "팀 ID (고유값)"},
            {"key": "icpc_id",              "required": False, "type": "str",  "desc": "ICPC CMS ID (선택)"},
            {"key": "label",                "required": False, "type": "str",  "desc": "좌석 번호 등 레이블"},
            {"key": "group_ids",            "required": True,  "type": "list", "desc": "카테고리 ID → groups 시트의 id 열 참조. 복수이면 콤마 구분"},
            {"key": "name",                 "required": True,  "type": "str",  "desc": "팀 이름"},
            {"key": "members",              "required": False, "type": "str",  "desc": "팀 구성원 (하나의 긴 문자열)"},
            {"key": "display_name",         "required": False, "type": "str",  "desc": "스코어보드 표시 이름 (없으면 name 사용)"},
            {"key": "organization_id",      "required": True,  "type": "str",  "desc": "소속 ID → organizations 시트의 id 열 참조"},
            {"key": "location.description", "required": False, "type": "str",  "desc": "팀 위치 설명"},
        ],
        "examples": [
            {"id": "team001", "label": "1", "group_ids": "highschool", "name": 'print("hello")',   "organization_id": "INST-aa"},
            {"id": "team002", "label": "2", "group_ids": "highschool", "name": "세미콜론 빠뜨림", "organization_id": "INST-aa"},
            {"id": "team003", "label": "3", "group_ids": "highschool", "name": "무한루프",         "organization_id": "INST-aa"},
            {"id": "team004", "label": "4", "group_ids": "highschool", "name": "404 Not Found",    "organization_id": "INST-bb"},
            {"id": "team005", "label": "5", "group_ids": "highschool", "name": "버그없음(거짓말)", "organization_id": "INST-bb"},
            {"id": "team006", "label": "6", "group_ids": "highschool", "name": "git pull 먼저",    "organization_id": "INST-cc"},
            {"id": "team007", "label": "7", "group_ids": "highschool", "name": "스택오버플로우",   "organization_id": "INST-cc"},
            {"id": "team008", "label": "8", "group_ids": "highschool", "name": "널포인터",         "organization_id": "INST-cc"},
        ],
    },
    "accounts": {
        "fields": [
            {"key": "id",       "required": True,  "type": "str", "desc": "계정 ID (고유값)"},
            {"key": "username", "required": True,  "type": "str", "desc": "로그인 아이디 (고유값)"},
            {"key": "password", "required": True,  "type": "str", "desc": "비밀번호"},
            {"key": "type",     "required": True,  "type": "str", "desc": "team / judge / admin / balloon 중 하나"},
            {"key": "team_id",  "required": False, "type": "str", "desc": "연결할 팀 ID → teams 시트의 id 열 참조"},
            {"key": "name",     "required": False, "type": "str", "desc": "계정 전체 이름"},
            {"key": "ip",       "required": False, "type": "str", "desc": "연결할 IP 주소"},
        ],
        "examples": [
            # team001 — 팀원 개별 계정 예시 (3인팀)
            {"id": "team001-alice",   "username": "team001-alice",   "password": "changeme", "type": "team", "name": "alice",   "team_id": "team001"},
            {"id": "team001-bob",     "username": "team001-bob",     "password": "changeme", "type": "team", "name": "bob",     "team_id": "team001"},
            {"id": "team001-charlie", "username": "team001-charlie", "password": "changeme", "type": "team", "name": "charlie", "team_id": "team001"},
            # team002 — 팀원 개별 계정 예시 (2인팀)
            {"id": "team002-dave",    "username": "team002-dave",    "password": "changeme", "type": "team", "name": "dave",    "team_id": "team002"},
            {"id": "team002-eve",     "username": "team002-eve",     "password": "changeme", "type": "team", "name": "eve",     "team_id": "team002"},
            # team003~008 — 팀 공용 계정 예시 (1팀 1계정)
            {"id": "team003", "username": "team003", "password": "changeme", "type": "team", "name": "무한루프",         "team_id": "team003"},
            {"id": "team004", "username": "team004", "password": "changeme", "type": "team", "name": "404 Not Found",    "team_id": "team004"},
            {"id": "team005", "username": "team005", "password": "changeme", "type": "team", "name": "버그없음(거짓말)", "team_id": "team005"},
            {"id": "team006", "username": "team006", "password": "changeme", "type": "team", "name": "git pull 먼저",    "team_id": "team006"},
            {"id": "team007", "username": "team007", "password": "changeme", "type": "team", "name": "스택오버플로우",   "team_id": "team007"},
            {"id": "team008", "username": "team008", "password": "changeme", "type": "team", "name": "널포인터",         "team_id": "team008"},
        ],
    },
}

SHEET_ORDER  = ["groups", "organizations", "teams", "accounts"]
SHEET_PREFIX = {name: i for i, name in enumerate(SHEET_ORDER, start=1)}
DEFAULT_XLSX = "domjudge_templates.xlsx"

# 시트 간 참조 관계: {시트: {필드: (참조 시트, 참조 필드)}}
CROSS_REFS: dict = {
    "teams": {
        "group_ids":       ("groups",        "id"),
        "organization_id": ("organizations",  "id"),
    },
    "accounts": {
        "team_id": ("teams", "id"),
    },
}


# ── 값 변환 ──────────────────────────────────────────────────────────────────

VALID_ACCOUNT_TYPES = {"team", "judge", "admin", "balloon"}

def convert_value(raw, field_type: str):
    """셀 원시값을 JSON 타입으로 변환. 빈 값이면 None 반환."""
    if raw is None or str(raw).strip() == "":
        return None
    s = str(raw).strip()
    if field_type == "bool":
        sl = s.lower()
        if sl in ("true", "1", "yes", "예"):
            return True
        if sl in ("false", "0", "no", "아니오"):
            return False
        raise ValueError(f"bool로 변환할 수 없는 값: '{s}' (true/false/1/0/yes/no/예/아니오 중 하나 입력)")
    if field_type == "int":
        try:
            return int(float(s))
        except ValueError:
            raise ValueError(f"정수로 변환할 수 없는 값: '{s}'")
    if field_type == "list":
        lst = [v.strip() for v in s.split(",") if v.strip()]
        return lst if lst else None
    return s


def set_nested(obj: dict, dotted_key: str, value) -> None:
    """점 표기법 키를 중첩 딕셔너리로 설정.
    예: "location.description" → obj["location"]["description"] = value
    """
    keys = dotted_key.split(".")
    for k in keys[:-1]:
        obj = obj.setdefault(k, {})
    obj[keys[-1]] = value


# ── 변환 로직 ─────────────────────────────────────────────────────────────────

def convert_sheet(ws, sheet_name: str) -> list[dict] | None:
    """시트 1개를 읽어 JSON 객체 목록으로 변환."""
    if sheet_name not in SCHEMAS:
        print(f"  [{sheet_name}] 알 수 없는 시트 이름 — 스킵")
        return []

    schema   = SCHEMAS[sheet_name]
    field_map = {f["key"]: f for f in schema["fields"]}

    # 1행: 헤더 읽기 (헤더 이름으로 열 인덱스 매핑)
    try:
        header_row = [cell.value for cell in next(ws.iter_rows(min_row=1, max_row=1))]
    except StopIteration:
        print(f"  [{sheet_name}] 빈 시트 (헤더 없음) — 건너뜀")
        return []
    col_map: dict[str, int] = {}
    unknown: list[str] = []

    for idx, h in enumerate(header_row):
        if h is None:
            continue
        key = str(h).strip()
        if key in field_map:
            col_map[key] = idx
        elif key:
            unknown.append(key)

    if not col_map:
        print(f"  [{sheet_name}] 인식된 헤더 없음 — 스킵")
        return None

    missing_required = [
        f["key"] for f in schema["fields"]
        if f["required"] and f["key"] not in col_map
    ]

    print(f"  [{sheet_name}]")
    print(f"    인식된 헤더 : {list(col_map.keys())}")
    if unknown:
        print(f"    무시된 헤더 : {unknown}")
    if missing_required:
        print(f"    [X] 필수 헤더 누락으로 변환 불가: {missing_required}")
        return None

    results: list[dict] = []
    skipped_rows: list[int] = []
    seen_ids: dict[str, int] = {}       # id → 첫 등장 행 번호
    dup_ids: set[str] = set()           # 중복된 id 집합
    seen_usernames: dict[str, int] = {} # username → 첫 등장 행 번호 (accounts 전용)
    dup_usernames: set[str] = set()     # 중복된 username 집합

    for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        # 완전히 빈 행 스킵
        if all(v is None or str(v).strip() == "" for v in row):
            continue

        obj: dict = {}
        skip_row = False

        for key, col_idx in col_map.items():
            field = field_map[key]
            raw   = row[col_idx] if col_idx < len(row) else None
            try:
                value = convert_value(raw, field["type"])
            except ValueError as e:
                if field["required"]:
                    print(f"    [!] {row_num}행 [{key}] 변환 오류 — {e}, 행 스킵")
                    skip_row = True
                    break
                else:
                    print(f"    [!] {row_num}행 [{key}] 변환 오류 — {e}, 해당 필드 생략")
                    continue

            if value is None:
                if field["required"]:
                    print(f"    [!] {row_num}행 [{key}] 필수 필드 누락 — 행 스킵")
                    skip_row = True
                    break
                continue  # 선택 필드이면 키 자체를 JSON에서 생략

            # accounts type 값 검증
            if sheet_name == "accounts" and key == "type":
                if value not in VALID_ACCOUNT_TYPES:
                    print(f"    [!] {row_num}행 [type] 허용되지 않는 값: '{value}' (team/judge/admin/balloon) — 엑셀을 수정 후 다시 실행하세요.")
                    sys.exit(1)

            if "." in key:
                set_nested(obj, key, value)
            else:
                obj[key] = value

        if skip_row:
            skipped_rows.append(row_num)
            continue

        if not obj:
            continue

        # id 중복 검사
        oid = obj.get("id")
        if oid is not None:
            if oid in seen_ids:
                print(f"    [!] {row_num}행 id 중복: '{oid}' — {seen_ids[oid]}행과 충돌")
                dup_ids.add(oid)
            else:
                seen_ids[oid] = row_num

        # username 중복 검사 (accounts 시트)
        if sheet_name == "accounts":
            uname = obj.get("username")
            if uname is not None:
                if uname in seen_usernames:
                    print(f"    [!] {row_num}행 username 중복: '{uname}' — {seen_usernames[uname]}행과 충돌")
                    dup_usernames.add(uname)
                else:
                    seen_usernames[uname] = row_num

        results.append(obj)

    if skipped_rows:
        print(f"    [!] 제외된 행: {skipped_rows}")

    if dup_ids:
        print(f"    [!] id 중복 오류로 변환 중단: {sorted(dup_ids)}")
        return None

    if dup_usernames:
        print(f"    [!] username 중복 오류로 변환 중단: {sorted(dup_usernames)}")
        return None

    print(f"    -> {len(results)}건 변환")
    return results


def validate_cross_refs(all_data: dict[str, list[dict]]) -> list[str]:
    """시트 간 참조 무결성 검사. 오류 메시지 목록 반환."""
    # 각 시트의 id 집합 구성
    id_sets = {
        sheet: {obj["id"] for obj in rows if "id" in obj}
        for sheet, rows in all_data.items()
    }

    checks = [
        ("teams",    "group_ids",       "groups",        "id"),
        ("teams",    "organization_id",  "organizations", "id"),
        ("accounts", "team_id",          "teams",         "id"),
    ]

    errors = []
    for sheet, field, src_sheet, src_field in checks:
        if sheet not in all_data or src_sheet not in id_sets:
            continue
        valid_ids = id_sets[src_sheet]

        for obj in all_data[sheet]:
            value = obj.get(field)
            if value is None:
                continue
            label = obj.get("name", obj.get("id", "?"))
            # list 타입 (group_ids)은 각 요소별 검사
            values = value if isinstance(value, list) else [value]
            for v in values:
                if v not in valid_ids:
                    errors.append(
                        f"  [{sheet}] '{label}' → {field}='{v}'"
                        f"  ('{src_sheet}.{src_field}'에 존재하지 않음)"
                    )
    return errors


def run_conversion(xlsx_path: str) -> None:
    output_dir = os.path.join(os.path.dirname(os.path.abspath(xlsx_path)), "result")
    os.makedirs(output_dir, exist_ok=True)
    print(f"읽는 중: {xlsx_path}\n")

    try:
        wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    except PermissionError:
        print(f"오류: '{os.path.basename(xlsx_path)}' 파일이 열려 있습니다. Excel을 닫고 다시 실행하세요.")
        sys.exit(1)
    except zipfile.BadZipFile:
        print(f"오류: '{os.path.basename(xlsx_path)}' 파일이 손상되었거나 올바른 xlsx 파일이 아닙니다.")
        sys.exit(1)

    # ── 1단계: 모든 시트 변환 ────────────────────────────────────────────────
    all_data: dict[str, list[dict]] = {}
    for sheet_name in wb.sheetnames:
        data = convert_sheet(wb[sheet_name], sheet_name)
        if data is not None:
            all_data[sheet_name] = data

    # ── 2단계: 변환 실패 시트 확인 ──────────────────────────────────────────
    failed = [s for s in SHEET_ORDER if s in wb.sheetnames and s not in all_data]
    if failed:
        print(f"\n[!] 변환 실패 시트: {failed} — 엑셀을 수정 후 다시 실행하세요.")
        sys.exit(1)

    # ── 3단계: 크로스 레퍼런스 검증 ─────────────────────────────────────────
    print()
    ref_errors = validate_cross_refs(all_data)
    if ref_errors:
        print("[!] 참조 오류 발견:")
        for e in ref_errors:
            print(e)
        print(f"\n  총 {len(ref_errors)}건 — 엑셀을 수정 후 다시 실행하세요.")
        sys.exit(1)
    print("[OK] 참조 무결성 검사 통과\n")

    # ── 4단계: JSON 파일 생성 ────────────────────────────────────────────────
    generated = []
    for sheet_name in SHEET_ORDER:  # 의존성 순서 유지
        if sheet_name not in all_data:
            continue
        prefix   = SHEET_PREFIX[sheet_name]
        out_path = os.path.join(output_dir, f"{prefix}-{sheet_name}.json")
        try:
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(all_data[sheet_name], f, ensure_ascii=False, indent=2)
        except PermissionError:
            print(f"  오류: '{os.path.basename(out_path)}' 파일이 열려 있습니다. 닫고 다시 실행하세요.")
            sys.exit(1)
        print(f"  파일 생성: {os.path.basename(out_path)}")
        generated.append(sheet_name)

    print("\n" + "─" * 50)
    print(f"완료: {len(generated)}개 JSON 파일 생성")
    if generated:
        print("\n[DOMjudge Import 순서]")
        for name in generated:
            i = SHEET_PREFIX[name]
            print(f"  {i}. Import JSON/YAML → {name:15s} → {i}-{name}.json")


# ── 템플릿 생성 ───────────────────────────────────────────────────────────────

def create_template(output_path: str) -> None:
    wb = Workbook()
    wb.remove(wb.active)

    CLR_REQ   = "2E75B6"  # 파란색  — 필수 필드 헤더
    CLR_OPT   = "70AD47"  # 초록색  — 선택 필드 헤더
    CLR_EX    = "F2F2F2"  # 연회색  — 예시 데이터 행
    CLR_WHITE = "FFFFFF"

    for sheet_name in SHEET_ORDER:
        schema = SCHEMAS[sheet_name]
        ws     = wb.create_sheet(title=sheet_name)
        fields = schema["fields"]

        # ── 1행: 헤더 ──────────────────────────────────────────────────────
        for col, field in enumerate(fields, start=1):
            cell  = ws.cell(row=1, column=col, value=field["key"])
            color = CLR_REQ if field["required"] else CLR_OPT
            cell.font      = Font(bold=True, color=CLR_WHITE, size=11)
            cell.fill      = PatternFill(fill_type="solid", fgColor=color)
            cell.alignment = Alignment(horizontal="center", vertical="center")

            # 헤더 셀에 툴팁 주석 추가
            label   = "★ 필수" if field["required"] else "○ 선택"
            comment = Comment(f"[{label}]\n{field['desc']}", "DOMjudge")
            comment.width  = 240
            comment.height = 65
            cell.comment   = comment

            # 열 너비: 키 길이 기반 자동 조정
            ws.column_dimensions[get_column_letter(col)].width = max(len(field["key"]) * 1.6 + 4, 18)

        ws.row_dimensions[1].height = 26
        ws.freeze_panes = "A2"  # 헤더 행 고정

        # ── 예시 행 (회색, 이탤릭) ─────────────────────────────────────────
        for row_idx, example in enumerate(schema["examples"], start=2):
            for col, field in enumerate(fields, start=1):
                value = example.get(field["key"], "")
                cell  = ws.cell(row=row_idx, column=col, value=value)
                cell.fill = PatternFill(fill_type="solid", fgColor=CLR_EX)
                cell.font = Font(color="AAAAAA", italic=True)

    # ── 시트 간 드롭다운 유효성 검사 ───────────────────────────────────────
    MAX_ROWS = 300  # 데이터가 있을 수 있는 최대 행

    def field_col(schema_name: str, field_key: str) -> str | None:
        """스키마에서 필드 키의 열 문자 반환 (예: "A", "D")."""
        for i, f in enumerate(SCHEMAS[schema_name]["fields"], start=1):
            if f["key"] == field_key:
                return get_column_letter(i)
        return None

    for sheet_name, refs in CROSS_REFS.items():
        ws = wb[sheet_name]
        fields = SCHEMAS[sheet_name]["fields"]

        for field_key, (src_sheet, src_field) in refs.items():
            tgt_col = field_col(sheet_name, field_key)
            src_col = field_col(src_sheet, src_field)
            if not tgt_col or not src_col:
                continue

            # 다른 시트 열을 드롭다운 소스로 지정
            formula = f"'{src_sheet}'!${src_col}$2:${src_col}${MAX_ROWS}"
            dv = DataValidation(
                type="list",
                formula1=formula,
                allow_blank=True,
                showDropDown=False,
                showErrorMessage=True,
                errorTitle="참조 오류",
                error=f"'{src_sheet}' 시트의 {src_field} 값을 입력하세요.",
            )
            ws.add_data_validation(dv)
            dv.sqref = f"{tgt_col}2:{tgt_col}{MAX_ROWS}"

            # 헤더 셀에 참조 관계 표시 (주황색)
            tgt_col_idx = next(i for i, f in enumerate(fields, start=1) if f["key"] == field_key)
            ws.cell(row=1, column=tgt_col_idx).fill = PatternFill(fill_type="solid", fgColor="C55A11")

    try:
        wb.save(output_path)
    except PermissionError:
        print(f"오류: '{os.path.basename(output_path)}' 파일이 열려 있습니다. Excel을 닫고 다시 실행하세요.")
        sys.exit(1)

    print(f"템플릿 생성됨: {output_path}\n")
    print("시트별 헤더 목록 (★ 필수 / ○ 선택):")
    print("─" * 60)
    for sheet_name in SHEET_ORDER:
        print(f"\n  [{sheet_name}]")
        for f in SCHEMAS[sheet_name]["fields"]:
            marker = "★" if f["required"] else "○"
            print(f"    {marker}  {f['key']:<25}  {f['desc']}")
    print()
    print("─" * 60)
    print("파란 헤더   = 필수 필드")
    print("초록 헤더   = 선택 필드")
    print("주황 헤더   = 다른 시트 참조 필드 (드롭다운 자동 연결)")
    print("회색 행     = 예시 데이터 (삭제 후 실제 데이터 입력)")
    print()
    print("[시트 간 참조 관계]")
    for sheet_name, refs in CROSS_REFS.items():
        for field_key, (src_sheet, src_field) in refs.items():
            print(f"  {sheet_name}.{field_key:20s} → {src_sheet}.{src_field}")


# ── 진입점 ────────────────────────────────────────────────────────────────────

def main() -> None:
    args = sys.argv[1:]

    if "--template" in args:
        script_dir  = os.path.dirname(os.path.abspath(__file__))
        output_path = os.path.join(script_dir, DEFAULT_XLSX)
        if os.path.isfile(output_path):
            answer = input(f"'{DEFAULT_XLSX}' 이 이미 존재합니다. 덮어쓸까요? [y/N] ").strip().lower()
            if answer != "y":
                print("취소됨.")
                return
        create_template(output_path)
        return

    # 변환 모드
    xlsx_name = args[0] if args else DEFAULT_XLSX
    if not os.path.isabs(xlsx_name):
        xlsx_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), xlsx_name)
    else:
        xlsx_path = xlsx_name

    if not os.path.isfile(xlsx_path):
        print(f"오류: 파일을 찾을 수 없습니다 → {xlsx_path}")
        print(f"  템플릿 생성:  python {os.path.basename(__file__)} --template")
        sys.exit(1)

    run_conversion(xlsx_path)


if __name__ == "__main__":
    main()
